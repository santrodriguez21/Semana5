package com.mismascotasfavoritas.presentador;

public interface InterfaceRecyclerViewPresentador {

    public void obtenerMascotasBaseDatos();

    public void mostrarMascotaRecyclerView();

}
